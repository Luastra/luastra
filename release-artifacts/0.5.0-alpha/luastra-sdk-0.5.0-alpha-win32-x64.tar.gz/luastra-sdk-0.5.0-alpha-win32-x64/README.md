# Luastra SDK 0.5.0-alpha

Target: win32-x64. This is a checksum-verified public-source alpha candidate.

Requirements: Node.js 24 or newer. No npm install or repository checkout is required.

Run `luastra doctor` after installation, then use `luastra create <directory>`.
