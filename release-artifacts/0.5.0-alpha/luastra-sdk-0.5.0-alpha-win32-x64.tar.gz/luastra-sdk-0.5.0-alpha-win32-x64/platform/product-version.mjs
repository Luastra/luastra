export const productVersion = "0.5.0-alpha";
