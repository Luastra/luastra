export const productVersion = "0.3.0-alpha";
